WICHTIG!
Die Hauptimplementation befindet sich in den .py Dateien.
Die .cpp und .exe Dateien sind Erweiterungen.